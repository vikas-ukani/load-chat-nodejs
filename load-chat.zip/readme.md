# README #

This project developed for load app chatting module ( messages ) using socket implementation.

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

*  git clone https://dignizant@bitbucket.org/dignizant/load-chat-nodejs.git

## install all node dependency  ##
* npm install 

## run development server  ##
* npm run dev

 
## Server Configuration For Live Project ##

 * Refer this link to live 
    https://www.digitalocean.com/community/tutorials/how-to-set-up-a-node-js-application-for-production-on-ubuntu-14-04

 * sudo npm install pm2 -g
 * pm2 start index.js
 
 